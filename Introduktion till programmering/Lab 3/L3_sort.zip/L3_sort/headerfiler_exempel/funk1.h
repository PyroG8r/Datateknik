#ifndef FUNK1_H
#define FUNK1_H

#include <iostream>

const int SIFFRAN = 123;

void hej( std::string );

#endif
