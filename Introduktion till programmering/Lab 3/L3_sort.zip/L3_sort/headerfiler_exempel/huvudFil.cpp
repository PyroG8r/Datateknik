// Läs README.md(.pdf)
#include "funk1.h"
#include "funk2.h"

#include <iostream>
using namespace std;

int main()
{
  cout << SIFFRAN << endl;
  hej( "Namn" );
  hej( "Annat Namn" );
  hoj();
  return 0;
}
