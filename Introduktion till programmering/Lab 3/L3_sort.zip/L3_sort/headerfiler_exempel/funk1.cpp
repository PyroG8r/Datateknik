#include "funk1.h"

using namespace std;

void hej( string n )
{
  cout << "HEJ " << n << endl;
}

