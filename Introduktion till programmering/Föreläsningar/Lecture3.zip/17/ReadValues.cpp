#include <iostream>
#include <string>

using namespace std;

int main()
{
  int value,sum=0;
  cout << "Type in 10 integer values:"<<endl;
  cin >> value;
  sum +=value;
  cin >> value;
   sum +=value;
  cin >> value;
   sum +=value;
  cin >> value;
   sum +=value;
  cout <<"The sum is: " <<sum <<endl;
  

return 0;
}
 
