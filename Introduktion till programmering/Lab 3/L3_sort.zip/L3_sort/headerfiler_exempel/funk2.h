#ifndef FUNK2_H
#define FUNK2_H

#include <iostream>

void hoj();

#endif
