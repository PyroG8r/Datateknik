#include "funk2.h"

using namespace std;

void hoj()
{
  cout << "HOJ!" << endl;
}

