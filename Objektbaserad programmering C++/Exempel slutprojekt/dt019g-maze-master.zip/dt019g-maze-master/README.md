# dt019g-maze


noob code :')

![Capturedwd](https://user-images.githubusercontent.com/43444902/61488994-e4850200-a9a9-11e9-9bc2-060499a73943.PNG)