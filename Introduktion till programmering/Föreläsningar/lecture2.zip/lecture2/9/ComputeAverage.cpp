#include <iostream>
using namespace std;

int main()
{
  cout << (1 + 2 + 3) / 3 << endl;

  return 0;
}
