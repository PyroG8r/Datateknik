# maze-generator
A final project from the course 'object-based programming in C++'

The cool effects of the maze are only viable from a linux terminal as the code use commands that clears the terminal and switches the terminal mode to raw sometimes.

The maze can also solve pre made mazes in textfile formats. The zip-file contains one custom maze in the file 'maze.txt'.
A custom maze can only be entered from the terminal with the command './main < maze.txt'.
<img width="683" alt="271703984_396531152270546_6927047325641388527_n" src="https://user-images.githubusercontent.com/78786414/150306701-1890d9c4-eecf-4a0b-9d1a-f83e99b84827.png">
<img width="683" alt="271200766_758481761779410_952117773286252632_n" src="https://user-images.githubusercontent.com/78786414/150307158-8184907d-bf69-4770-97f7-9a4fd7d44860.png">
<img width="683" alt="272053761_333739205281344_4438970654410276067_n" src="https://user-images.githubusercontent.com/78786414/150307169-15a5e1ef-3021-4261-8266-b7ec0438ff86.png">
<img width="683" alt="271512833_261566942748741_4302234901727609444_n" src="https://user-images.githubusercontent.com/78786414/150307187-d912eeb9-4e63-4eb9-b310-a59bc100e687.png">
<img width="683" alt="271607102_635530037648812_4074126133261096976_n" src="https://user-images.githubusercontent.com/78786414/150307195-867620f9-90e7-4bec-8a82-ffd1ebe392e8.png">
